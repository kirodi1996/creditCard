export const environment = {
  production: true,
  apiKey: "AIzaSyDq6qM7fNRQ13hplxi6oevGBvQq4nutBgs",
  authDomain: "creditcard-af55d.firebaseapp.com",
  databaseURL: "https://creditcard-af55d.firebaseio.com",
  projectId: "creditcard-af55d",
  storageBucket: "creditcard-af55d.appspot.com",
  messagingSenderId: "135135375910",
  appId: "1:135135375910:web:ad098643a94d6c194d6ce7",
  measurementId: "G-L1EFEL52K6"
};
